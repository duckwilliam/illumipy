#!/usr/bin/env python3
"""
Default Values for illumipy
"""
__all__ = ['API_KEY_DEFAULT', 'CITY_DEFAULT', 'COUNTRY_DEFAULT']

API_KEY_DEFAULT = 'fc26e33305a8c4240d70606378900c76'
CITY_DEFAULT = 'Hamburg'
COUNTRY_DEFAULT = 'Germany'


